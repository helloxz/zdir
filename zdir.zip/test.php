<?php
	if(is_dir("D:\wwwroot\listdir/lay")) {
		echo 'ok';
	}
	else{
		echo 'no';
	}
?>