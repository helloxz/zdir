<?php
	$siteinfo = array(
		"title"		=>	"Zdir",
		"keywords"	=>	"zdir"
	);

	//需要忽略的目录
	$ignore	= array(
		".",
		".git",
		"config.php",
		"index.php",
		"static",
		"LICENSE"
	);	
?>