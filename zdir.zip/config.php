<?php
	$siteinfo = array(
		"title"		=>	"Zdir 实用的目录列表程序",
		"keywords"	=>	"zdir,h5ai,Directory Lister,Fdscript,目录列表,目录索引",
		"description"	=>	"Zdir是一款使用PHP开发的目录列表程序，简单实用，免费开源。"
	);

	//需要忽略的目录
	$ignore	= array(
		".",
		".git",
		"favicon.ico",
		"functions",
		"config.php",
		"index.php",
		"static",
		"LICENSE"
	);	
?>